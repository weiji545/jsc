import World from './world/World'

// 对外导出 World，供 Vue 组件使用
export {
  World
}

export default World


